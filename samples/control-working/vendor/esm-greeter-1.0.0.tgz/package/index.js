// 1.0.0 moved to ESM and loads its templates asynchronously at start-up (top-level await).
const template = await Promise.resolve((name) => `Hello, ${name}!`);

export function greet(name) {
  return template(name);
}
