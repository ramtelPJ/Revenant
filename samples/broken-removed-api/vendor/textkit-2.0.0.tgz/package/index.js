// textkit 2.0.0: slugify() was removed. toSlug() replaces it.
exports.toSlug = function toSlug(text) {
  return String(text).toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
};
